---
layout: post
date: 2021-08-12 09:00:00-0400
inline: true
related_posts: false
---

**[ Paper ]** I will be presenting our paper "MHz2k: MPC from HE over Z2k" at [Crypto 2021](https://crypto.iacr.org/2021/){:target="\_blank"}. The live session will be at Aug 20th 15:00~15:50 UTC. The pre-recorded video is now on [youtube](https://youtu.be/Hi6pU7eT0k4){:target="\_blank"}. 