---
layout: post
date: 2023-08-29 09:00:00-0400
inline: true
related_posts: false
---

**[ Award ]** My thesis "A Study on Homomorphic Packing: Definitions, Constructions, and Limitations" received the Best Doctoral Dissertation Award (\$2000) from College of Natural Sciences @ SNU. 