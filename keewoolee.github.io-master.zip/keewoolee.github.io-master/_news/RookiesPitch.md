---
layout: post
date: 2022-03-08 09:00:00-0400
inline: true
related_posts: false
---

**[ Talk ]** Being selected as an outstanding graduate student of Math@SNU, I will give an invited talk at [BK Colloquium](/assets/img/rookiespitch.jpg){:target="\_blank"} on Mar 22nd.