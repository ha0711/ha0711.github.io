---
layout: post
date: 2024-04-19 09:00:00-0400
inline: true
related_posts: false
---

**[ Talk ]** I am giving a talk at [Bay Area Crypto Day](https://sites.google.com/view/bayareacryptoday/2024-apr){:target="\_blank"} on April 19th.