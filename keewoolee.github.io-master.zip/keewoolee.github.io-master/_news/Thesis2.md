---
layout: post
date: 2024-04-19 08:00:00-0400
inline: true
related_posts: false
---

**[ Award ]** My thesis "A Study on Homomorphic Packing: Definitions, Constructions, and Limitations" received the Best Doctoral Dissertation Award (\$1000) from the Korean Mathematical Society. 