---
layout: post
date: 2024-03-29 09:00:00-0400
inline: true
related_posts: false
---

**[ Paper ]** The paper "Bit Security as Cost to Demonstrate Advantage" is accepted to [IACR CiC](https://cic.iacr.org/){:target="\_blank"}.