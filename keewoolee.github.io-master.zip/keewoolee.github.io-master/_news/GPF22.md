---
layout: post
date: 2022-05-26 09:00:00-0400
inline: true
related_posts: false
---

**[ Award ]** Being selected in the top 10% among the recipients of Global PhD Fellowship, I received additional $4000 from National Research Foundation of Korea.