---
layout: post
date: 2023-09-29 09:00:00-0400
inline: true
related_posts: false
---

**[ Paper ]** The paper "VeriSimplePIR: Verifiability in SimplePIR at No Online Cost for Honest Servers" is accepted to [USENIX Security 2024](https://www.usenix.org/conference/usenixsecurity24/){:target="\_blank"}.