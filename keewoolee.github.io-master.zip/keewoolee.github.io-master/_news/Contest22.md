---
layout: post
date: 2022-09-01 09:00:00-0400
inline: true
related_posts: false
---

**[ Award ]** The paper "Bit Security as Cost to Demonstrate Advantage" won Best Award (\$3000) in [National Cryptography Contest](https://keewoolee.github.io/assets/img/contest22.jpeg){:target="\_blank"}.