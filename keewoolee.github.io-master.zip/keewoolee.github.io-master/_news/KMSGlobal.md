---
layout: post
date: 2022-10-01 09:00:00-0400
inline: true
related_posts: false
---

**[ Talk ]** I will give an invited talk at the Focus Session on "Discrete Math and Math of Computer Science" at [2022 Global KMS (Korean Math. Soc.) International Conference](https://www.kms.or.kr/md_meet/main.html?period=82){:target="\_blank"} on Oct 20th, which is held to celebrate the promotion of Korea as IMU (Internat'l Math. Union) member of Group 5.